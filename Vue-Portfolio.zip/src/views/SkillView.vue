<template>
    <!-- Skills Section -->
    <div class="absolute top-0 right-0 pt-4 px-6 pb-24 w-full md:w-3/4 lg:w-4/5 xl:w-5/6 bg-white dark:bg-gray-900">
        <div class="md:ml-6 lg:ml-6 xl:ml-6">
            <h2 class="text-3xl font-bold text-gray-800 dark:text-gray-200 text-center mb-12">Skills
            </h2>
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <!-- Design Skills -->
                <div class="bg-white dark:bg-gray-700 p-6 rounded-lg shadow-md">
                    <div class="flex items-center mb-4">
                        <div class="w-10 h-10 flex items-center justify-center bg-blue-100 p-3 rounded-full mr-4">
                            <i class="fa-solid fa-palette text-accent text-xl"></i>
                        </div>
                        <h3 class="text-xl font-semibold text-primary dark:text-white">Graphic Design</h3>
                    </div>
                    <div class="space-y-3">
                        <div class="flex items-center">
                            <div class="w-2 h-2 bg-accent rounded-full mr-3"></div>
                            <span class="text-gray-600 dark:text-white">
                                1. Design logos, posters, flyers, and brochures<br>
                                2. Develop and maintain brand identity<br>
                                3. Create social media and digital content<br>
                                4. Edit and retouch photos<br>
                                5. Arrange layouts with clear typography<br>
                                6. Prepare files for print and production<br>
                                7. Collaborate with clients and teams<br>
                                8. Follow design trends and update skills<br>
                                9. Manage and organize design assets<br>
                                10. Use design software (Photoshop, Illustrator, Figma, etc.) effectively
                            </span>
                        </div>
                    </div>
                </div>

                <!-- IT Skills -->
                <div class="bg-white dark:bg-gray-700 p-6 rounded-lg shadow-md">
                    <div class="flex items-center mb-4">
                        <div class="w-10 h-10 flex items-center justify-center bg-blue-100 p-3 rounded-full mr-4">
                            <i class="fa-solid fa-network-wired text-accent text-xl"></i>
                        </div>
                        <h3 class="text-xl font-semibold text-primary dark:text-white">IT Support</h3>
                    </div>
                    <div class="space-y-3">
                        <div class="flex items-center">
                            <div class="w-2 h-2 bg-accent rounded-full mr-3"></div>
                            <span class="text-gray-600 dark:text-white">
                                1. Support production-related IT equipment<br>
                                2. Troubleshoot network and connectivity issues<br>
                                3. Set up and configure computers, printers, and scanners<br>
                                4. Maintain factory management systems (ERP)<br>
                                5. Perform preventive maintenance on IT devices<br>
                                6. Provide user support and basic training<br>
                                7. Maintain CCTV and security systems<br>
                                8. Document IT activities and system configurations<br>
                                9. Ensure IT compliance and workplace safety
                            </span>
                        </div>
                    </div>
                </div>

                <!-- Coding Skills -->
                <div class="bg-white dark:bg-gray-700 p-6 rounded-lg shadow-md">
                    <div class="flex items-center mb-4">
                        <div class="w-10 h-10 flex items-center justify-center bg-blue-100 p-3 rounded-full mr-4">
                            <i class="fa-solid fa-code text-accent text-xl"></i>
                        </div>
                        <h3 class="text-xl font-semibold text-primary dark:text-white">Web Development</h3>
                    </div>
                    <div class="space-y-3">
                        <div class="flex items-center">
                            <div class="w-2 h-2 bg-accent rounded-full mr-3"></div>
                            <span class="text-secontext-gray-600 dark:text-white">
                                1. Design and build responsive websites<br>
                                2. Write clean HTML, CSS, JavaScript, and PHP code<br>
                                3. Develop and manage MySQL databases<br>
                                4. Create dynamic and interactive web pages<br>
                                5. Debug and fix frontend/backend issues<br>
                                6. Optimize websites for speed and performance<br>
                                7. Ensure mobile and cross-browser compatibility<br>
                                8. Integrate forms, authentication, and user features<br>
                                9. Maintain and update existing websites<br>
                                10. Collaborate with designers and clients for project goals<br>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>